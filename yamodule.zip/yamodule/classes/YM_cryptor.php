<?php
/**
* Module is prohibited to sales! Violation of this condition leads to the deprivation of the license!
*
* @category  Front Office Features
* @package   Yandex Payment Solution
* @author    Yandex.Money <cms@yamoney.ru>
* @copyright © 2015 NBCO Yandex.Money LLC
* @license   https://money.yandex.ru/doc.xml?id=527052
*/

class YmCryptor
{
    protected $key = '';
    protected $cipher = MCRYPT_RIJNDAEL_256;
    protected $cipher_mode = MCRYPT_MODE_CBC;

    public function setKey($key)
    {
        $this->key = hash('sha256', $key, true);
    }

    public function encrypt($data)
    {
        $data = serialize($data);
        $init_size = mcrypt_get_iv_size($this->cipher, $this->cipher_mode);
        $init_vect = mcrypt_create_iv($init_size, MCRYPT_RAND);
        $str = $this->randomString(Tools::strlen($this->key)).$init_vect.
            mcrypt_encrypt($this->cipher, $this->key, $data, $this->cipher_mode, $init_vect);
        return base64_encode($str);
    }

    public function decrypt($data)
    {
        $data = base64_decode($data);
        $data = Tools::substr($data, Tools::strlen($this->key));
        $init_size = mcrypt_get_iv_size($this->cipher, $this->cipher_mode);
        $init_vect = Tools::substr($data, 0, $init_size);
        $data = Tools::substr($data, $init_size);
        $str = mcrypt_decrypt($this->cipher, $this->key, $data, $this->cipher_mode, $init_vect);
        return unserialize($str);
    }

    protected function randomString($len)
    {
        $str = '';
        $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $pool_len = Tools::strlen($pool);
        for ($i = 0; $i < $len; $i++) {
            $str .= Tools::substr($pool, mt_rand(0, $pool_len - 1), 1);
        }
        return $str;
    }
}
